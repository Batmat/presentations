package org.toulouseju;

public class Jugger {
	private final String nom;
	private final String prenom;
	private final int age;
	public Jugger(String prenom, String nom, int age) {
		this.prenom = prenom;
		this.nom = nom;
		this.age = age;
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public int getAge() {
		return age;
	}
}
