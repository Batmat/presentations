package org.toulouseju;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import static org.fest.assertions.Assertions.*;

public class SomeTest {
	@Test
	public void moyenneDÂge() {
		int total = 0;
		int nombre = 0;
		for (Jugger jugger : getJugTeam()) {
			total += jugger.getAge();
			nombre++;
		}
		assertThat(total / nombre).isEqualTo(22);
	}

	@Test
	public void plusJeuneAge() {
		int ageMini = 1000;
		for (Jugger jugger : getJugTeam()) {
			if (jugger.getAge() < ageMini) {
				ageMini = jugger.getAge();
			}
		}
		assertThat(ageMini).isEqualTo(18);
	}

	@Test
	public void plusGrandAge() {
		int ageMaxi = -1;
		for (Jugger jugger : getJugTeam()) {
			if (jugger.getAge() > ageMaxi) {
				ageMaxi = jugger.getAge();
			}
		}
		assertThat(ageMaxi).isEqualTo(25);
	}
	@Test
	public void teamSize() {
		assertThat(getJugTeam().size()).isEqualTo(10);
	}

	public Collection<Jugger> getJugTeam() {
		List<Jugger> equipeToulouseJug = new ArrayList<Jugger>();
		equipeToulouseJug.add(new Jugger("Alexis", "Krier", 22));
		equipeToulouseJug.add(new Jugger("Gaël", "Blondelle", 25));
		equipeToulouseJug.add(new Jugger("Sylvain", "Wallez", 25));
		equipeToulouseJug.add(new Jugger("Nicolas", "Zozol", 25));
		equipeToulouseJug.add(new Jugger("Vincent", "Barrier", 20));
		equipeToulouseJug.add(new Jugger("Vincent", "Ferries", 21));
		equipeToulouseJug.add(new Jugger("Marianne", "Jullien", 18));
		equipeToulouseJug.add(new Jugger("Leonardo", "Noleto", 21));
		equipeToulouseJug.add(new Jugger("Antoine", "Vernois", 23));
		equipeToulouseJug.add(new Jugger("Baptiste", "Mathus", 21));
		return equipeToulouseJug;
	}
}
